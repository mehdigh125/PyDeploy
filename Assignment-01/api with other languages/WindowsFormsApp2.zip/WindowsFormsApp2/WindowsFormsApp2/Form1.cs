﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var client = new RestClient();
            var url = "https://www.fruityvice.com/api/fruit/" + textBox1.Text;
            var request = new RestRequest(url, Method.Get);
            RestResponse response = client.Get(request);
            richTextBox1.Text = response.Content;
        }
    }
}
